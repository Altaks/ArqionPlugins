package fr.altaks.helemoney.api.bdd;

import java.sql.SQLException;

public class DatabaseManager {
	
	private DBConnection activatedConnection;
	
	public DatabaseManager() {
		
		this.activatedConnection = new DBConnection(new DBCredentials("localhost", "SkyBlock", "mHPLX3I09JafaBg6", "skyblock", 3306));
		
	}
	
	public void close() {
		try {
			this.activatedConnection.close();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	public DBConnection getActivatedConnection() {
		return this.activatedConnection;
	}

}
